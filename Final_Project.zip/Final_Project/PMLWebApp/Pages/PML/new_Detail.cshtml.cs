using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PMLWebApp.Pages.PML
{
    public class NewDetailModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
